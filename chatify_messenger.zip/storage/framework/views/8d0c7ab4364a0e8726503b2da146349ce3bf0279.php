<!DOCTYPE html>
<html>

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Chating</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css"
        integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.js">
    </script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .offline_icon {
            position: absolute;
            height: 15px;
            width: 15px;
            background-color: #252725;
            border-radius: 50%;
            bottom: 0.2em;
            right: 0.4em;
            border: 1.5px solid white;
        }

        .uTabs {
            padding: 5px;
            display: flex;
            align-items: center;
            justify-content: space-evenly;
            background: black;
            color: white;
        }

        .uTabs #sTab {
            width: 40%;
            background: rgb(40, 187, 40);
            text-align: center;
            cursor: pointer;
            padding: 5px;
        }

        .uTabs #gTab {
            width: 40%;
            background: brown;
            text-align: center;
            cursor: pointer;
            padding: 5px;
        }
    </style>
    <!------ Include the above in your HEAD tag ---------->
    <link rel="stylesheet" href="<?php echo e(asset('css/messenger.css')); ?>">
    <script src="<?php echo e(asset('assets/js/push.min.js')); ?>"></script>


</head>
<!--Coded With Love By Mutiullah Samim-->

<body>

    

    <?php
        $users = DB::table('users')
            ->where('id', '!=', Auth::user()->id)
            ->get();
        // dd($users);
    ?>
    <div class="container-fluid h-100">
        <div class="row justify-content-center h-100">
            <div class="col-md-4 col-xl-3 chat">
                <div class="card mb-sm-3 mb-md-0 contacts_card">
                    <div class="card-header">
                        <div class="input-group">
                            <input type="text" placeholder="Search..." name="" class="form-control search">
                            <div class="input-group-prepend">
                                <span class="input-group-text search_btn"><i class="fas fa-search"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="card-body contacts_body">
                        <div class="col-md-12 uTabs">
                            <div id="sTab">Single</div>
                            <div id="gTab">Groups</div>
                        </div>
                        <div class="sTab">
                            <ui class="contacts">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="user-chat" data-username="<?php echo e($user->name); ?>"
                                        data-id="<?php echo e($user->id); ?>" id="userClck" style="cursor: pointer;">
                                        <div class="d-flex bd-highlight">
                                            <div class="img_cont">
                                                <?php if($user->profile): ?>
                                                    <img src="<?php echo e(asset('uploads/users/' . $user->profile)); ?>"
                                                        class="rounded-circle user_img">
                                                <?php else: ?>
                                                    <img src="https://static.turbosquid.com/Preview/001292/481/WV/_D.jpg"
                                                        class="rounded-circle user_img">
                                                <?php endif; ?>
                                                <?php if($user->status == '1'): ?>
                                                    <span class="online_icon"></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="user_info">
                                                <span><?php echo e($user->name); ?></span>
                                                <p><?php echo e($user->email); ?></p>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ui>
                        </div>
                        <div class="gTab">
                        </div>
                    </div>
                    <div class="card-footer"></div>
                </div>
            </div>
            <div class="col-md-8 col-xl-6 chat chatBody">
                <div class="card">
                    <div class="card-header msg_head">
                        <div class="d-flex bd-highlight">
                            <div class="img_cont">
                                <img src="<?php echo e(asset('uploads/users/' . Auth::user()->profile)); ?>"
                                    class="rounded-circle user_img" id="user-profile-image">
                                <span class="offline_icon user-status"></span>
                            </div>
                            <div class="user_info">
                                <span id="user-profile-name"><?php echo e(Auth::user()->name); ?></span>
                                <p id="user-status"><?php echo e(Auth::user()->email); ?></p>
                            </div>
                            <div class="video_cam">
                                <span><i class="fas fa-video"></i></span>
                                <span><i class="fas fa-phone"></i></span>
                            </div>
                        </div>
                        <span id="action_menu_btn"><i class="fa fa-sign-out"></i></span>
                    </div>
                    <div class="card-body msg_card_body ">
                        <!-- Receiver's message -->
                        <div class="d-flex justify-content-start rcvMsg mb-4">
                            <div class="img_cont_msg rcvMsg-img">
                                <img src="https://static.turbosquid.com/Preview/001292/481/WV/_D.jpg"
                                    class="rounded-circle user_img_msg">
                            </div>
                            <div class="msg_cotainer">
                                Hi, how are you Samim?
                                <span class="msg_time">8:40 AM, Today</span>
                            </div>
                        </div>
                        <!-- Sender's message -->
                        <div class="d-flex justify-content-end sndrMsg mb-4">
                            <div class="msg_cotainer_send">
                                Hi Khalid, I am good. Thanks, how about you?
                                <span class="msg_time_send">8:55 AM, Today</span>
                            </div>
                            <div class="img_cont_msg sndrMsg-img">
                                <img src="https://static.turbosquid.com/Preview/001292/481/WV/_D.jpg"
                                    class="rounded-circle user_img_msg">
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="input-group">
                            <div class="input-group-append">
                                <span class="input-group-text attach_btn"><i class="fas fa-paperclip"></i></span>
                            </div>
                            <input type="hidden" name="reciever_id" id="recieverid" value="">
                            <input type="text" id="messageInput" class="form-control" name="message"
                                placeholder="Type here...">
                            <div class="input-group-append" id="sendMessageButton">
                                <span class="input-group-text send_btn"><i class="fas fa-location-arrow"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <div id="user-info" data-name="<?php echo e(Auth::user()->name); ?>"
        data-profile="<?php echo e(asset('uploads/users/' . Auth::user()->profile)); ?>" hidden></div>

    <script type="module" src="<?php echo e(asset('js/app.js')); ?>"></script>

    <script>
        var authId = <?php echo json_encode((string) auth()->user()->id, 15, 512) ?>;
        var authProfile = $('#user-info').data('profile');
        var authName = <?php echo json_encode(auth()->user()->name, 15, 512) ?>;
        var receiverId = $('#recieverid').val();
        var message = $('#messageInput').val();
        window.assetBaseUrl = "<?php echo e(asset('')); ?>";
        var usersUrl = "<?php echo e(route('user.get')); ?>";
        var submitUrl = "<?php echo e(route('send-message.post')); ?>";
        var fetchedUrl = "<?php echo e(route('fetch-messages.post')); ?>";

        console.log('Chat page urls', submitUrl, submitUrl, fetchedUrl);
    </script>

</body>

</html>
<?php /**PATH D:\Projects\chatify_messenger\resources\views/messenger.blade.php ENDPATH**/ ?>